#include "PathGoal.h"
PathGoal::~PathGoal() {
}