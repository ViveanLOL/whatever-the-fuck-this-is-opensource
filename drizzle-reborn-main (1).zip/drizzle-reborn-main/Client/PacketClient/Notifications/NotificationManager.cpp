#include "NotificationManager.h"

NotificationManager notifManager;